#pragma once

#include "ofMain.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{

	public:
		//Add first GUI
		ofxPanel gui;
		ofxIntSlider countX;
		ofxFloatSlider stepX;
		ofxFloatSlider twistX;
		ofxFloatSlider scale;
		ofxIntSlider countY;
		ofxFloatSlider stepY, twistY;

		//add gui group for global
		ofxGuiGroup globalGroup;
		ofxFloatSlider globalScale;
		ofxFloatSlider globalRotation;
		ofxFloatSlider globalBackground;

		//add gui group for primitives
		ofxGuiGroup primGroup;
		ofxFloatSlider shiftY, rotate;
		ofxVec2Slider size;
		ofxColorSlider color;
		ofxToggle filled, type;

		//various variable
		bool showGui;

		//methods
		void setup();
		void update();
		void draw();
		void exit();
		//custom methods
		void stripePattern();
		void initParameters();
		void matrixPattern();

		//events and interaction 
		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

};
